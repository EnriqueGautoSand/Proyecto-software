VERSION_MAJOR = 0
VERSION_MINOR = 0
VERSION_BUILD = 1
VERSION_INFO = (VERSION_MAJOR, VERSION_MINOR, VERSION_BUILD)
VERSION_STRING = "%d.%d.%d" % VERSION_INFO
AUTHOR_NAME = "You name goes here"
DESCRIPTION = "Small text to resume your addon"
AUTHOR_EMAIL = "youiremail@somewhere.com"

__version__ = VERSION_INFO

